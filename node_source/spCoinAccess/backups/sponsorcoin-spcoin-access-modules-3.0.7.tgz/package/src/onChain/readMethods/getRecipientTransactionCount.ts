export { default } from './getRecipientRateTransactionCount';
