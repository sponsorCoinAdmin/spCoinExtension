export { default } from './getRecipientRateTransactionAt';
