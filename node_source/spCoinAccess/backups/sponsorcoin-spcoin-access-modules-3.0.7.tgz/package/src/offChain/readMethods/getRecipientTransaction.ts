export { default } from './getRecipientRateTransaction';
