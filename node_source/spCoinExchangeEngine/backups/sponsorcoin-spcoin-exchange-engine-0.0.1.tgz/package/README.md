# @sponsorcoin/spcoin-exchange-engine

Portable ExchangeContext runtime — the provider, read/write hooks, and
cross-process sync client — shared between `spcoin-nextjs-front-end` and the
Merit Wallet browser extension (`spCoinExtension`).

Standalone rather than nested under `@sponsorcoin/spcoin-common`:
`spcoin-common` is deliberately pure types/enums/static panel-tree data with
zero runtime dependencies (so anything can depend on it without weight);
this package is where the actual engine lives instead — a React
`ExchangeProvider`, hooks like `useWebExchangeContext`, and the sync client
that patches shared `ExchangeContext` state (`accounts`/`network`/
`displayPanels`/`displayStack`, per `@sponsorcoin/spcoin-common`'s own
`APICoreSyncedMembers`/`ExchangeContextPatch` types) across processes.
`spcoin-panels` (portable UI) and this engine are both meant to depend on
`spcoin-common` for shape, not on each other.

Empty as of 2026-09-16, on purpose — this is the scaffold/wiring step
(package created, built, registered with the NPM Deployment tool). The
actual runtime — `ExchangeProvider.tsx`, `useProviderSetters.ts`,
`exchangeContextClient.ts`, `exchangeContextServerStore.ts`, and friends,
today living only in `spcoin-nextjs-front-end`'s own
`lib/structure/exchangeContextCore/` and `lib/context/` — moves here
incrementally, not in one shot, as each piece is actually ported for a real
consumer (starting with the extension needing real wallet/network/account
sync instead of its current local-`useState`/`spcoin-feeds`-REST
placeholder — see `spCoinExtension/docs` or the parent app's
`docs/handoff.md` for that plan's current status).
