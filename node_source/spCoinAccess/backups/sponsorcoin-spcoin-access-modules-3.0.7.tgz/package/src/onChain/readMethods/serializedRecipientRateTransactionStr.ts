export { default } from './getSerializedRecipientRateList';
