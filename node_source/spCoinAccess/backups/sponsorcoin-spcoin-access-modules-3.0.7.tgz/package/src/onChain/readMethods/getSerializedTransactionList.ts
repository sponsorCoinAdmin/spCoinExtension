export { default } from './getSerializedRateTransactionList';
