export { default } from './getRecipientRateTransactionList';
