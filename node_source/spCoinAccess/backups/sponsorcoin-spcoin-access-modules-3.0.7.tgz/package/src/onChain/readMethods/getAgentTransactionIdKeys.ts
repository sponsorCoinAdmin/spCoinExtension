// @ts-nocheck
import { createDynamicHandler } from '../../readMethodRuntime';

export default createDynamicHandler('getAgentTransactionIdKeys');
